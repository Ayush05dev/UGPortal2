// import React from "react";

// function Landing() {
//     return (
//         <>
//         <div>Home Page</div>
//         </>
//     )
// }

// export default Landing;

// src/pages/HomePage.jsx
import React from "react";
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center">
      <div className="w-full max-w-4xl p-8 bg-white rounded-lg shadow-lg text-center">
        <h1 className="text-4xl font-bold text-blue-600 mb-4">
          Welcome to the College Attendance System
        </h1>
        <p className="text-gray-700 text-lg mb-8">
          Manage your attendance, view subjects, and monitor marks efficiently.
          Choose your role below to continue.
        </p>

        <div className="flex justify-center gap-8 mt-8">
          {/* Student Section */}
          <div className="w-1/2 bg-blue-50 p-6 rounded-lg shadow hover:shadow-lg transition-shadow">
            <h2 className="text-2xl font-semibold text-blue-500">
              For Students
            </h2>
            <p className="text-gray-600 mb-4">
              Access your profile, view your attendance, and track your
              performance.
            </p>
            <Link
              to="login"
              className="px-4 py-2 bg-blue-500 text-white rounded-md shadow hover:bg-blue-600 transition"
            >
              Student Login
            </Link>
            <Link
              to="/register"
              className="ml-4 px-4 py-2 border border-blue-500 text-blue-500 rounded-md shadow hover:bg-blue-500 hover:text-white transition"
            >
              Register as Student
            </Link>
          </div>

          {/* Professor Section */}
          <div className="w-1/2 bg-green-50 p-6 rounded-lg shadow hover:shadow-lg transition-shadow">
            <h2 className="text-2xl font-semibold text-green-500">
              For Professors
            </h2>
            <p className="text-gray-600 mb-4">
              Manage attendance, upload marks, and monitor student progress.
            </p>
            <Link
              to="/professors/login"
              className="px-4 py-2 bg-green-500 text-white rounded-md shadow hover:bg-green-600 transition"
            >
              Professor Login
            </Link>
            <Link
              to="/professors/register"
              className="ml-4 px-4 py-2 border border-green-500 text-green-500 rounded-md shadow hover:bg-green-500 hover:text-white transition"
            >
              Register as Professor
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
