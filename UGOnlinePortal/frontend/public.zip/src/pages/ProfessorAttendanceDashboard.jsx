// // // import React, { useState, useEffect } from "react";
// // // import axios from "axios";

// // // const ProfessorDashboard = () => {
// // //   const [profile, setProfile] = useState(null);
// // //   const [subjects, setSubjects] = useState([]);
// // //   const [selectedSubject, setSelectedSubject] = useState("");
// // //   const [selectedSection, setSelectedSection] = useState("");
// // //   const [studentAttendance, setStudentAttendance] = useState([]);

// // //   useEffect(() => {
// // //     const fetchProfessorData = async () => {
// // //       try {
// // //         const token = localStorage.getItem("token");

// // //         // Fetching professor profile data
// // //         const profileRes = await axios.get(
// // //           "http://localhost:5000/api/professor/profile",
// // //           { headers: { Authorization: `Bearer ${token}` } }
// // //         );

// // //         // Fetching professor subjects
// // //         const subjectsRes = await axios.get(
// // //           "http://localhost:5000/api/professor/dashboard",
// // //           { headers: { Authorization: `Bearer ${token}` } }
// // //         );

// // //         // Setting profile and subjects state
// // //         setProfile(profileRes.data);
// // //         setSubjects(subjectsRes.data);
// // //       } catch (error) {
// // //         console.error("Error fetching professor data:", error);
// // //       }
// // //     };
// // //     fetchProfessorData();
// // //   }, []);

// // //   const handleSubjectSelect = async () => {
// // //     try {
// // //       if (selectedSubject && selectedSection) {
// // //         const token = localStorage.getItem("token");
// // //         const response = await axios.get(
// // //           `http://localhost:5000/api/professor/attendance?subject=${selectedSubject}&section=${selectedSection}`,
// // //           { headers: { Authorization: `Bearer ${token}` } }
// // //         );
// // //         setStudentAttendance(response.data);
// // //       }
// // //     } catch (error) {
// // //       console.error("Error fetching attendance data:", error);
// // //     }
// // //   };

// // //   // Loading spinner or message while data is being fetched
// // //   if (!profile || !subjects.length) {
// // //     return (
// // //       <div className="flex justify-center items-center min-h-screen text-2xl">
// // //         Loading...
// // //       </div>
// // //     );
// // //   }

// // //   return (
// // //     <div className="p-8 max-w-screen-lg mx-auto space-y-8">
// // //       {/* Header */}
// // //       <h2 className="text-3xl font-bold text-center text-indigo-600">
// // //         Professor Dashboard
// // //       </h2>

// // //       {/* Profile Section */}
// // //       {profile && (
// // //         <div className="bg-white shadow-lg rounded-lg p-6">
// // //           <h3 className="text-xl font-semibold text-gray-800">Profile</h3>
// // //           <div className="mt-4 space-y-2">
// // //             <p className="text-gray-700">
// // //               <strong>Name:</strong> {profile.name}
// // //             </p>
// // //             <p className="text-gray-700">
// // //               <strong>Email:</strong> {profile.email}
// // //             </p>
// // //           </div>
// // //         </div>
// // //       )}

// // //       {/* Subject and Section Selector */}
// // //       <div className="bg-white shadow-lg rounded-lg p-6">
// // //         <h3 className="text-xl font-semibold text-gray-800">
// // //           Select Subject and Section
// // //         </h3>

// // //         <div className="mt-4 flex flex-wrap gap-4">
// // //           {/* Subject Dropdown */}
// // //           <select
// // //             className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
// // //             value={selectedSubject}
// // //             onChange={(e) => setSelectedSubject(e.target.value)}
// // //           >
// // //             <option value="">Select Subject</option>
// // //             {subjects.map((subject) => (
// // //               <option key={subject._id} value={subject._id}>
// // //                 {subject.name} ({subject.code})
// // //               </option>
// // //             ))}
// // //           </select>

// // //           {/* Section Dropdown */}
// // //           {profile.sections && (
// // //             <select
// // //               className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
// // //               value={selectedSection}
// // //               onChange={(e) => setSelectedSection(e.target.value)}
// // //             >
// // //               <option value="">Select Section</option>
// // //               {profile.sections.map((section) => (
// // //                 <option key={section} value={section}>
// // //                   {section}
// // //                 </option>
// // //               ))}
// // //             </select>
// // //           )}

// // //           {/* Button */}
// // //           <button
// // //             className="w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-all duration-300"
// // //             onClick={handleSubjectSelect}
// // //           >
// // //             View Attendance
// // //           </button>
// // //         </div>
// // //       </div>

// // //       {/* Student Attendance Table */}
// // //       {studentAttendance.length > 0 && (
// // //         <div className="bg-white shadow-lg rounded-lg p-6">
// // //           <h3 className="text-xl font-semibold text-gray-800">
// // //             Student Attendance
// // //           </h3>
// // //           <table className="min-w-full mt-4 table-auto text-gray-700">
// // //             <thead className="bg-indigo-600 text-white">
// // //               <tr>
// // //                 <th className="px-4 py-2 text-left">Roll Number</th>
// // //                 <th className="px-4 py-2 text-left">Name</th>
// // //                 <th className="px-4 py-2 text-left">Current Attendance</th>
// // //               </tr>
// // //             </thead>
// // //             <tbody>
// // //               {studentAttendance.map((student) => (
// // //                 <tr key={student._id} className="border-b hover:bg-indigo-100">
// // //                   <td className="px-4 py-2">{student.rollNumber}</td>
// // //                   <td className="px-4 py-2">{student.name}</td>
// // //                   <td className="px-4 py-2">{student.attendancePercentage}%</td>
// // //                 </tr>
// // //               ))}
// // //             </tbody>
// // //           </table>
// // //         </div>
// // //       )}
// // //     </div>
// // //   );
// // // };

// // // export default ProfessorDashboard;

// // import React, { useState, useEffect } from "react";
// // import axios from "axios";

// // const ProfessorDashboard = () => {
// //   const [profile, setProfile] = useState(null);
// //   const [subjects, setSubjects] = useState([]);
// //   const [selectedSubject, setSelectedSubject] = useState("");
// //   const [selectedSection, setSelectedSection] = useState("");
// //   const [studentAttendance, setStudentAttendance] = useState([]);

// //   useEffect(() => {
// //     const fetchProfessorData = async () => {
// //       try {
// //         const token = localStorage.getItem("token");

// //         // Fetching professor profile data
// //         const profileRes = await axios.get(
// //           "http://localhost:5000/api/professor/profile",
// //           { headers: { Authorization: `Bearer ${token}` } }
// //         );

// //         // Fetching professor subjects
// //         const subjectsRes = await axios.get(
// //           "http://localhost:5000/api/professor/dashboard",
// //           { headers: { Authorization: `Bearer ${token}` } }
// //         );

// //         setProfile(profileRes.data);
// //         setSubjects(subjectsRes.data);
// //       } catch (error) {
// //         console.error("Error fetching professor data:", error);
// //       }
// //     };

// //     fetchProfessorData();
// //   }, []);

// //   const handleSubjectSelect = async () => {
// //     try {
// //       if (selectedSubject && selectedSection) {
// //         const token = localStorage.getItem("token");
// //         const response = await axios.get(
// //           `http://localhost:5000/api/professor/attendance?subject=${selectedSubject}&section=${selectedSection}`,
// //           { headers: { Authorization: `Bearer ${token}` } }
// //         );
// //         setStudentAttendance(response.data);
// //       }
// //     } catch (error) {
// //       console.error("Error fetching attendance data:", error);
// //     }
// //   };

// //   // const handleAttendanceToggle = async (studentId, attendanceStatus) => {
// //   //   // console.log("Student ID:", studentId); // Log student ID to see if it's correctly passed
// //   //   if (!studentId) {
// //   //     console.error("Student ID is missing");
// //   //     return;
// //   //   }
// //   //   try {
// //   //     // console.log("Attendance status:", attendanceStatus);
// //   //     const response = await axios.put(
// //   //       `http://localhost:5000/api/professor/attendance2/${student.studentId}`,
// //   //       { attendance: student.attendance }
// //   //     );
// //   //     console.log("Attendance updated:", response.data);
// //   //   } catch (error) {
// //   //     console.error("Error updating attendance:", error);
// //   //   }
// //   // };
// //   const handleAttendanceToggle = async (studentId, currentAttendance) => {
// //     try {
// //       const token = localStorage.getItem("token");
// //       const newAttendance =
// //         currentAttendance === "Present" ? "Absent" : "Present";
// //       // const response = await axios.put(
// //       //   `http://localhost:5000/api/professor/attendance2/${studentId}`,
// //       //   { attendance: newAttendance },
// //       //   { headers: { Authorization: `Bearer ${token}` } }
// //       // );
// //       const response = await axios.post(
// //         `http://localhost:5000/api/professor/mark-attendence`,

// //         { headers: { Authorization: `Bearer ${token}` } }
// //       );
// //       console.log("Attendance updated:", response.data);
// //       setStudentAttendance((prevAttendance) =>
// //         prevAttendance.map((student) =>
// //           student._id === studentId
// //             ? { ...student, attendance: newAttendance }
// //             : student
// //         )
// //       );
// //     } catch (error) {
// //       console.error("Error updating attendance:", error);
// //     }
// //   };

// //   if (!profile || !subjects.length) {
// //     return (
// //       <div className="flex justify-center items-center min-h-screen text-2xl">
// //         Loading...
// //       </div>
// //     );
// //   }

// //   return (
// //     <div className="p-8 max-w-screen-lg mx-auto space-y-8">
// //       <h2 className="text-3xl font-bold text-center text-indigo-600">
// //         Professor Dashboard
// //       </h2>

// //       {/* Profile Section */}
// //       {profile && (
// //         <div className="bg-white shadow-lg rounded-lg p-6">
// //           <h3 className="text-xl font-semibold text-gray-800">Profile</h3>
// //           <div className="mt-4 space-y-2">
// //             <p className="text-gray-700">
// //               <strong>Name:</strong> {profile.name}
// //             </p>
// //             <p className="text-gray-700">
// //               <strong>Email:</strong> {profile.email}
// //             </p>
// //           </div>
// //         </div>
// //       )}

// //       {/* Subject and Section Selector */}
// //       <div className="bg-white shadow-lg rounded-lg p-6">
// //         <h3 className="text-xl font-semibold text-gray-800">
// //           Select Subject and Section
// //         </h3>

// //         <div className="mt-4 flex flex-wrap gap-4">
// //           <select
// //             className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
// //             value={selectedSubject}
// //             onChange={(e) => setSelectedSubject(e.target.value)}
// //           >
// //             <option value="">Select Subject</option>
// //             {subjects.map((subject) => (
// //               <option key={subject._id} value={subject._id}>
// //                 {subject.name} ({subject.code})
// //               </option>
// //             ))}
// //           </select>

// //           {profile.sections?.length > 0 && (
// //             <select
// //               className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
// //               value={selectedSection}
// //               onChange={(e) => setSelectedSection(e.target.value)}
// //             >
// //               <option value="">Select Section</option>
// //               {profile.sections.map((section) => (
// //                 <option key={section} value={section}>
// //                   {section}
// //                 </option>
// //               ))}
// //             </select>
// //           )}

// //           <button
// //             className="w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-all duration-300"
// //             onClick={handleSubjectSelect}
// //           >
// //             View Attendance
// //           </button>
// //         </div>
// //       </div>

// //       {/* Student Attendance Table */}
// //       {studentAttendance.length > 0 && (
// //         <div className="bg-white shadow-lg rounded-lg p-6">
// //           <h3 className="text-xl font-semibold text-gray-800">
// //             Student Attendance
// //           </h3>
// //           <table className="min-w-full mt-4 table-auto text-gray-700">
// //             <thead className="bg-indigo-600 text-white">
// //               <tr>
// //                 <th className="px-4 py-2 text-left">Roll Number</th>
// //                 <th className="px-4 py-2 text-left">Name</th>
// //                 <th className="px-4 py-2 text-left">Classes Attended</th>
// //                 <th className="px-4 py-2 text-left">Attendance</th>
// //                 <th className="px-4 py-2 text-left">Action</th>
// //               </tr>
// //             </thead>
// //             <tbody>
// //               {studentAttendance.map((student) => (
// //                 <tr
// //                   key={student._id || student.rollNumber}
// //                   className="border-b hover:bg-indigo-100"
// //                 >
// //                   <td className="px-4 py-2">{student.rollNumber}</td>
// //                   <td className="px-4 py-2">{student.name}</td>
// //                   <td className="px-4 py-2">{student.classesAttended}</td>
// //                   <td className="px-4 py-2">{student.attendancePercentage}%</td>
// //                   <td className="px-4 py-2">
// //                     {console.log("Student object:", student)}
// //                     <button
// //                       className={`px-4 py-2 text-white rounded-lg ${
// //                         student.attendance === "Present"
// //                           ? "bg-green-500 hover:bg-green-600"
// //                           : "bg-red-500 hover:bg-red-600"
// //                       }`}
// //                       // onClick={
// //                       //   (student) => handleAttendanceToggle(student)
// //                       //   // student.studentId,
// //                       //   // student.attendance
// //                       // }
// //                       onClick={() =>
// //                         handleAttendanceToggle(student._id, student.attendance)
// //                       }
// //                     >
// //                       {student.attendance === "Present"
// //                         ? "Mark Absent"
// //                         : "Mark Present"}
// //                     </button>
// //                   </td>
// //                 </tr>
// //               ))}
// //             </tbody>
// //           </table>
// //         </div>
// //       )}
// //     </div>
// //   );
// // };

// // export default ProfessorDashboard;

// import React, { useState, useEffect } from "react";
// import axios from "axios";

// const ProfessorDashboard = () => {
//   const [profile, setProfile] = useState(null);
//   const [subjects, setSubjects] = useState([]);
//   const [selectedSubject, setSelectedSubject] = useState("");
//   const [selectedSection, setSelectedSection] = useState("");
//   const [studentAttendance, setStudentAttendance] = useState([]);

//   useEffect(() => {
//     const fetchProfessorData = async () => {
//       try {
//         const token = localStorage.getItem("token");

//         // Fetching professor profile data
//         const profileRes = await axios.get(
//           "http://localhost:5000/api/professor/profile",
//           { headers: { Authorization: `Bearer ${token}` } }
//         );

//         // Fetching professor subjects
//         const subjectsRes = await axios.get(
//           "http://localhost:5000/api/professor/dashboard",
//           { headers: { Authorization: `Bearer ${token}` } }
//         );

//         setProfile(profileRes.data);
//         setSubjects(subjectsRes.data);
//       } catch (error) {
//         console.error("Error fetching professor data:", error);
//       }
//     };

//     fetchProfessorData();
//   }, []);

//   const handleSubjectSelect = async () => {
//     try {
//       if (selectedSubject && selectedSection) {
//         const token = localStorage.getItem("token");
//         const response = await axios.get(
//           `http://localhost:5000/api/professor/attendance?subject=${selectedSubject}&section=${selectedSection}`,
//           { headers: { Authorization: `Bearer ${token}` } }
//         );
//         setStudentAttendance(response.data);
//       }
//     } catch (error) {
//       console.error("Error fetching attendance data:", error);
//     }
//   };

//   const handleAttendanceToggle = async (studentId, currentAttendance) => {
//     try {
//       const token = localStorage.getItem("token");
//       const newAttendance =
//         currentAttendance === "Present" ? "Absent" : "Present";
//       const response = await axios.put(
//         `http://localhost:5000/api/professor/attendance2/${student.studentId}`,
//         { attendance: newAttendance },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );
//       console.log("Attendance updated:", response.data);
//       setStudentAttendance((prevAttendance) =>
//         prevAttendance.map((student) =>
//           student._id === studentId
//             ? { ...student, attendance: newAttendance }
//             : student
//         )
//       );
//     } catch (error) {
//       console.error("Error updating attendance:", error);
//     }
//   };

//   if (!profile || !subjects.length) {
//     return (
//       <div className="flex justify-center items-center min-h-screen text-2xl">
//         Loading...
//       </div>
//     );
//   }

//   return (
//     <div className="p-8 max-w-screen-lg mx-auto space-y-8">
//       <h2 className="text-3xl font-bold text-center text-indigo-600">
//         Professor Dashboard
//       </h2>

//       {/* Profile Section */}
//       {profile && (
//         <div className="bg-white shadow-lg rounded-lg p-6">
//           <h3 className="text-xl font-semibold text-gray-800">Profile</h3>
//           <div className="mt-4 space-y-2">
//             <p className="text-gray-700">
//               <strong>Name:</strong> {profile.name}
//             </p>
//             <p className="text-gray-700">
//               <strong>Email:</strong> {profile.email}
//             </p>
//           </div>
//         </div>
//       )}

//       {/* Subject and Section Selector */}
//       <div className="bg-white shadow-lg rounded-lg p-6">
//         <h3 className="text-xl font-semibold text-gray-800">
//           Select Subject and Section
//         </h3>
//         <div className="mt-4 flex flex-wrap gap-4">
//           <select
//             className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
//             value={selectedSubject}
//             onChange={(e) => setSelectedSubject(e.target.value)}
//           >
//             <option value="">Select Subject</option>
//             {subjects.map((subject) => (
//               <option key={subject._id} value={subject._id}>
//                 {subject.name} ({subject.code})
//               </option>
//             ))}
//           </select>

//           {profile.sections?.length > 0 && (
//             <select
//               className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
//               value={selectedSection}
//               onChange={(e) => setSelectedSection(e.target.value)}
//             >
//               <option value="">Select Section</option>
//               {profile.sections.map((section) => (
//                 <option key={section} value={section}>
//                   {section}
//                 </option>
//               ))}
//             </select>
//           )}
//           <button
//             className="w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-all duration-300"
//             onClick={handleSubjectSelect}
//           >
//             View Attendance
//           </button>
//         </div>
//       </div>

//       {/* Student Attendance Table */}
//       {studentAttendance.length > 0 && (
//         <div className="bg-white shadow-lg rounded-lg p-6">
//           <h3 className="text-xl font-semibold text-gray-800">
//             Student Attendance
//           </h3>
//           <table className="min-w-full mt-4 table-auto text-gray-700">
//             <thead className="bg-indigo-600 text-white">
//               <tr>
//                 <th className="px-4 py-2 text-left">Roll Number</th>
//                 <th className="px-4 py-2 text-left">Name</th>
//                 <th className="px-4 py-2 text-left">Classes Attended</th>
//                 <th className="px-4 py-2 text-left">Attendance</th>
//                 <th className="px-4 py-2 text-left">Action</th>
//               </tr>
//             </thead>
//             <tbody>
//               {studentAttendance.map((student) => (
//                 <tr
//                   key={student._id || student.rollNumber}
//                   className="border-b hover:bg-indigo-100"
//                 >
//                   <td className="px-4 py-2">{student.rollNumber}</td>
//                   <td className="px-4 py-2">{student.name}</td>
//                   <td className="px-4 py-2">{student.classesAttended}</td>
//                   <td className="px-4 py-2">{student.attendancePercentage}%</td>
//                   <td className="px-4 py-2">
//                     <button
//                       className={`px-4 py-2 text-white rounded-lg ${
//                         student.attendance === "Present"
//                           ? "bg-green-500 hover:bg-green-600"
//                           : "bg-red-500 hover:bg-red-600"
//                       }`}
//                       onClick={() =>
//                         handleAttendanceToggle(student.studentId, student.attendance)
//                       }
//                     >
//                       {student.attendance === "Present"
//                         ? "Mark Absent"
//                         : "Mark Present"}
//                     </button>
//                   </td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}
//     </div>
//   );
// };

// export default ProfessorDashboard;
import React, { useState, useEffect } from "react";
import axios from "axios";

const ProfessorAttendanceDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [selectedSubject, setSelectedSubject] = useState("");
  const [selectedSection, setSelectedSection] = useState("");
  const [studentAttendance, setStudentAttendance] = useState([]);

  useEffect(() => {
    const fetchProfessorData = async () => {
      try {
        const token = localStorage.getItem("token");

        // Fetching professor profile data
        const profileRes = await axios.get(
          "http://localhost:5000/api/professor/profile",
          { headers: { Authorization: `Bearer ${token}` } }
        );

        // Fetching professor subjects
        const subjectsRes = await axios.get(
          "http://localhost:5000/api/professor/dashboard",
          { headers: { Authorization: `Bearer ${token}` } }
        );

        setProfile(profileRes.data);
        setSubjects(subjectsRes.data);
      } catch (error) {
        console.error("Error fetching professor data:", error);
      }
    };

    fetchProfessorData();
  }, []);

  const handleSubjectSelect = async () => {
    try {
      if (selectedSubject && selectedSection) {
        const token = localStorage.getItem("token");
        const response = await axios.get(
          `http://localhost:5000/api/professor/attendance?subject=${selectedSubject}&section=${selectedSection}`,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setStudentAttendance(response.data);
      }
    } catch (error) {
      console.error("Error fetching attendance data:", error);
    }
  };

  const handleAttendanceToggle = async (studentId, currentAttendance) => {
    try {
      const token = localStorage.getItem("token");
      const newAttendance =
        currentAttendance === "Present" ? "Absent" : "Present";
      const response = await axios.post(
        `http://localhost:5000/api/professor/mark-attendance`,
        {
          subjectId: selectedSubject,
          section: selectedSection,
          branch: profile.branch,
          attendanceData: [{ studentId, status: newAttendance }],
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      console.log("Attendance updated:", response.data);
      setStudentAttendance((prevAttendance) =>
        prevAttendance.map((student) =>
          student._id === studentId
            ? { ...student, attendance: newAttendance }
            : student
        )
      );
    } catch (error) {
      console.error("Error updating attendance:", error);
    }
  };

  if (!profile || !subjects.length) {
    return (
      <div className="flex justify-center items-center min-h-screen text-2xl">
        Loading...
      </div>
    );
  }

  return (
    <div className="p-8 max-w-screen-lg mx-auto space-y-8">
      <h2 className="text-3xl font-bold text-center text-indigo-600">
        Professor Dashboard
      </h2>

      {/* Profile Section */}
      {profile && (
        <div className="bg-white shadow-lg rounded-lg p-6">
          <h3 className="text-xl font-semibold text-gray-800">Profile</h3>
          <div className="mt-4 space-y-2">
            <p className="text-gray-700">
              <strong>Name:</strong> {profile.name}
            </p>
            <p className="text-gray-700">
              <strong>Email:</strong> {profile.email}
            </p>
          </div>
        </div>
      )}

      {/* Subject and Section Selector */}
      <div className="bg-white shadow-lg rounded-lg p-6">
        <h3 className="text-xl font-semibold text-gray-800">
          Select Subject and Section
        </h3>

        <div className="mt-4 flex flex-wrap gap-4">
          <select
            className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
          >
            <option value="">Select Subject</option>
            {subjects.map((subject) => (
              <option key={subject._id} value={subject._id}>
                {subject.name} ({subject.code})
              </option>
            ))}
          </select>

          {profile.sections?.length > 0 && (
            <select
              className="w-full sm:w-1/2 border border-gray-300 rounded-lg p-3 text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
            >
              <option value="">Select Section</option>
              {profile.sections.map((section) => (
                <option key={section} value={section}>
                  {section}
                </option>
              ))}
            </select>
          )}

          <button
            className="w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white rounded-lg shadow-md hover:bg-indigo-700 transition-all duration-300"
            onClick={handleSubjectSelect}
          >
            View Attendance
          </button>
        </div>
      </div>

      {/* Student Attendance Table */}
      {studentAttendance.length > 0 && (
        <div className="bg-white shadow-lg rounded-lg p-6">
          <h3 className="text-xl font-semibold text-gray-800">
            Student Attendance
          </h3>
          <table className="min-w-full mt-4 table-auto text-gray-700">
            <thead className="bg-indigo-600 text-white">
              <tr>
                <th className="px-4 py-2 text-left">Roll Number</th>
                <th className="px-4 py-2 text-left">Name</th>
                <th className="px-4 py-2 text-left">Classes Attended</th>
                <th className="px-4 py-2 text-left">Attendance</th>
                <th className="px-4 py-2 text-left">Action</th>
              </tr>
            </thead>
            <tbody>
              {studentAttendance.map((student) => (
                <tr
                  key={student._id || student.rollNumber}
                  className="border-b hover:bg-indigo-100"
                >
                  <td className="px-4 py-2">{student.rollNumber}</td>
                  <td className="px-4 py-2">{student.name}</td>
                  <td className="px-4 py-2">{student.classesAttended}</td>
                  <td className="px-4 py-2">{student.attendancePercentage}%</td>
                  <td className="px-4 py-2">
                    <button
                      className={`px-4 py-2 text-white rounded-lg ${
                        student.attendance === "Present"
                          ? "bg-green-500 hover:bg-green-600"
                          : "bg-red-500 hover:bg-red-600"
                      }`}
                      onClick={() =>
                        handleAttendanceToggle(student._id, student.attendance)
                      }
                    >
                      {student.attendance === "Present"
                        ? "Mark Absent"
                        : "Mark Present"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default ProfessorAttendanceDashboard;
