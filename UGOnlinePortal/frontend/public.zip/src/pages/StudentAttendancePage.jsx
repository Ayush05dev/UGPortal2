// import React, { useEffect, useState } from "react";
// import axios from "axios";

// const StudentDashboard = () => {
//   const [profile, setProfile] = useState(null);
//   const [attendance, setAttendance] = useState([]);

//   useEffect(() => {
//     const fetchStudentData = async () => {
//       try {
//         const token = localStorage.getItem("token");
//         const profileRes = await axios.get(
//           "http://localhost:5000/api/student/profile",
//           {
//             headers: { Authorization: `Bearer ${token}` },
//           }
//         );
//         const attendanceRes = await axios.get(
//           "http://localhost:5000/api/student/attendance",
//           {
//             headers: { Authorization: `Bearer ${token}` },
//           }
//         );

//         setProfile(profileRes.data);
//         setAttendance(attendanceRes.data);
//       } catch (error) {
//         console.error("Error fetching student data:", error);
//       }
//     };
//     fetchStudentData();
//   }, []);

//   return (
//     <div className="p-6">
//       <h2 className="text-2xl font-bold mb-4">Student Dashboard</h2>

//       {profile && (
//         <div className="mb-6">
//           <h3 className="text-xl font-semibold">Profile</h3>
//           <p>
//             <strong>Name:</strong> {profile.name}
//           </p>
//           <p>
//             <strong>Email:</strong> {profile.email}
//           </p>
//           <p>
//             <strong>Roll Number:</strong> {profile.rollNumber}
//           </p>
//         </div>
//       )}

//       <h3 className="text-xl font-semibold mb-4">Attendance</h3>
//       <table className="table-auto w-full">
//         <thead>
//           <tr>
//             <th>Subject</th>
//             <th>Code</th>
//             <th>Attendance Records</th>
//           </tr>
//         </thead>
//         <tbody>
//           {attendance.map((subject) => (
//             <tr key={subject.code}>
//               <td>{subject.subject}</td>
//               <td>{subject.code}</td>
//               <td>
//                 {subject.records.map((record, index) => (
//                   <p key={index}>
//                     {record.date} - {record.status}
//                   </p>
//                 ))}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default StudentDashboard;

import React, { useEffect, useState } from "react";
import axios from "axios";

const StudentDashboard = () => {
  const [profile, setProfile] = useState(null);
  const [attendance, setAttendance] = useState([]);

  useEffect(() => {
    const fetchStudentData = async () => {
      try {
        const token = localStorage.getItem("token");
        const profileRes = await axios.get(
          "http://localhost:5000/api/student/profile",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        const attendanceRes = await axios.get(
          "http://localhost:5000/api/student/attendance",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setProfile(profileRes.data);
        setAttendance(attendanceRes.data);
      } catch (error) {
        console.error("Error fetching student data:", error);
      }
    };
    fetchStudentData();
  }, []);

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <div className="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-blue-600 mb-6 text-center">
          Student Dashboard
        </h2>

        {profile && (
          <div className="bg-blue-100 p-4 rounded-lg mb-6 shadow-md">
            <h3 className="text-xl font-semibold text-blue-700 mb-2">
              Profile
            </h3>
            <div className="space-y-2 text-blue-900">
              <p>
                <strong className="text-blue-800">Name:</strong> {profile.name}
              </p>
              <p>
                <strong className="text-blue-800">Email:</strong>{" "}
                {profile.email}
              </p>
              <p>
                <strong className="text-blue-800">Roll Number:</strong>{" "}
                {profile.rollNumber}
              </p>
            </div>
          </div>
        )}

        <h3 className="text-xl font-semibold text-blue-700 mb-4">Attendance</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left bg-white shadow-md rounded-lg overflow-hidden">
            <thead>
              <tr className="bg-blue-500 text-white uppercase text-sm leading-normal">
                <th className="py-3 px-6">Subject</th>
                <th className="py-3 px-6">Code</th>
                <th className="py-3 px-6">Attendance Records</th>
              </tr>
            </thead>
            <tbody className="text-gray-700 text-sm font-light">
              {attendance.map((subject) => (
                <tr
                  key={subject.code}
                  className="border-b border-gray-200 hover:bg-gray-100"
                >
                  <td className="py-3 px-6 font-medium">{subject.subject}</td>
                  <td className="py-3 px-6">{subject.code}</td>
                  <td className="py-3 px-6">
                    {subject.records.map((record, index) => (
                      <p
                        key={index}
                        className={`px-2 py-1 rounded-full inline-block ${
                          record.status === "Present"
                            ? "bg-green-100 text-green-600"
                            : "bg-red-100 text-red-600"
                        }`}
                      >
                        {record.date} - {record.status}
                      </p>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
