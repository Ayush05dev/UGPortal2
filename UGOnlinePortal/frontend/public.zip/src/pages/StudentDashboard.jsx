import React from "react";
import StudentAttendance from "./StudentAttendancePage";
function StudentDashboard() {
  return (
    <>
      <div>Student Dashboard</div>
      <StudentAttendance />
    </>
  );
}

export default StudentDashboard;
