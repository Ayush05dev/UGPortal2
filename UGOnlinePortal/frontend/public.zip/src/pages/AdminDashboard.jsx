import React from "react";

function AdminDashboard() {
    return (
        <>
        <div>Admin Dashboard</div>
        </>
    )
}

export default AdminDashboard;