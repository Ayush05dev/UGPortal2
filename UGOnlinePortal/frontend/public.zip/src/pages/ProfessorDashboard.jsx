import React from "react";
import ProfessorAttendanceDashboard from "./ProfessorAttendanceDashboard";
function ProfessorDashboard() {
  return (
    <>
      <div>Professor Dashboard</div>
      <ProfessorAttendanceDashboard />
    </>
  );
}

export default ProfessorDashboard;
