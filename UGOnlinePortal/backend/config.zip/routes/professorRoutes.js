// // src/routes/professorRoutes.js
// const express = require("express");
// const {
//   registerProfessor,
//   loginProfessor,
//   getProfessorProfile,
//   updateProfessorProfile,
//   uploadMarks,
//   markAttendance,
//   getDashboard,
//   createSubject,
//   getAttendance,
//   // getAttendanceForSubjectAndSection,
// } = require("../controllers/professorController.js");
// const { authMiddleware } = require("../middleware/authMiddleware.js");

// const router = express.Router();

// router.post("/register", registerProfessor);
// router.post("/login", loginProfessor);
// router.get("/profile", authMiddleware, getProfessorProfile);
// router.put("/profile", authMiddleware, updateProfessorProfile);
// router.post("/upload-marks", authMiddleware, uploadMarks);
// // Attendance route (Protected)
// router.post("/mark-attendance", authMiddleware, markAttendance);
// // Assuming you have a function to fetch subjects from the database
// router.get("/dashboard", authMiddleware, getDashboard);

// router.post("/create-subject", authMiddleware, createSubject);

// // router.get("/attendance", authMiddleware, getAttendanceForSubjectAndSection);
// router.get("/attendance", authMiddleware, getAttendance);

// // PUT: Update student's attendance
// router.put("/attendance/:studentId", authMiddleware, async (req, res) => {
//   const { studentId } = req.params; // Get student ID from URL parameter
//   const { attendance } = req.body; // Get attendance value from request body ("present" or "absent")

//   // Check if the attendance is valid
//   if (attendance !== "present" && attendance !== "absent") {
//     return res
//       .status(400)
//       .json({
//         message: "Invalid attendance value. Must be 'present' or 'absent'.",
//       });
//   }

//   try {
//     // Find the student by ID and update their attendance status
//     const student = await Student.findById(studentId);
//     if (!student) {
//       return res.status(404).json({ message: "Student not found" });
//     }

//     // Update the student's attendance
//     student.attendance = attendance; // Assuming 'attendance' is a field in the Student model
//     await student.save(); // Save the updated student

//     // Respond with the updated student
//     res
//       .status(200)
//       .json({ message: "Attendance updated successfully", student });
//   } catch (error) {
//     console.error("Error updating attendance:", error);
//     res.status(500).json({ message: "Server error" });
//   }
// });

// module.exports = router;

const express = require("express");
const {
  registerProfessor,
  loginProfessor,
  getProfessorProfile,
  updateProfessorProfile,
  uploadMarks,
  markAttendance,
  getDashboard,
  createSubject,
  getAttendance,
} = require("../controllers/professorController.js");
const { authMiddleware } = require("../middleware/authMiddleware.js");
const Student = require("../models/Student"); // Import the Student model

const router = express.Router();

router.post("/register", registerProfessor);
router.post("/login", loginProfessor);
router.get("/profile", authMiddleware, getProfessorProfile);
router.put("/profile", authMiddleware, updateProfessorProfile);
router.post("/upload-marks", authMiddleware, uploadMarks);
// Attendance route (Protected)
router.post("/mark-attendance", authMiddleware, markAttendance);
// Assuming you have a function to fetch subjects from the database
router.get("/dashboard", authMiddleware, getDashboard);

router.post("/create-subject", authMiddleware, createSubject);

// Get attendance for all students
router.get("/attendance", authMiddleware, getAttendance);

router.put("/attendance2/:studentId", authMiddleware, async (req, res) => {
  const { studentId } = req.params; // Get student ID from URL parameter
  console.log("Attempting to update attendance for student:", studentId); // Add this line
  console.log("studentId", studentId);
  const { attendance } = req.body; // Get attendance value from request body

  // Check if attendance is valid
  if (attendance !== "Present" && attendance !== "Absent") {
    return res.status(400).json({
      message: "Invalid attendance value. Must be 'present' or 'absent'.",
    });
  }

  try {
    const student = await Student.findById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    student.attendance.push({ date: new Date(), status: attendance }); // Add attendance record
    await student.save();

    res
      .status(200)
      .json({ message: "Attendance updated successfully", student });
  } catch (error) {
    console.error("Error updating attendance:", error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
