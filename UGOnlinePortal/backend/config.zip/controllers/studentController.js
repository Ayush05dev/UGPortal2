const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Student = require("../models/Student.js");
const Subject = require("../models/Subject.js");
const Attendance = require("../models/Attendance.js");
exports.registerStudent = async (req, res) => {
  try {
    const { rollNumber, name, email, password, branch, section } = req.body;

    const existingStudent = await Student.findOne({
      $or: [{ email }, { rollNumber }],
    });
    if (existingStudent) {
      return res.status(400).json({ message: "Student already exists" });
    }

    const newStudent = new Student({
      rollNumber,
      name,
      email,
      password,
      branch,
      section,
    });

    await newStudent.save();

    res.status(201).json({ message: "Student registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.loginStudent = async (req, res) => {
  try {
    const { email, password } = req.body;

    const student = await Student.findOne({ email });
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    const isPasswordCorrect = await student.comparePassword(password);

    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: student._id, role: "student" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.status(200).json({ token });
  } catch (error) {
    console.log("error", error);
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.getStudentProfile = async (req, res) => {
  try {
    const student = await Student.findById(req.userId).select("-password");
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    res.status(200).json(student);
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.updateStudentProfile = async (req, res) => {
  try {
    const { name, email } = req.body;

    const updatedStudent = await Student.findByIdAndUpdate(
      req.userId,
      { name, email },
      { new: true }
    ).select("-password");

    res.status(200).json(updatedStudent);
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

// Get attendance for the logged-in student across all subjects
exports.getStudentAttendance = async (req, res) => {
  try {
    // Retrieve student ID from authenticated request
    const studentId = req.userId;

    // Fetch attendance records for the student, including subject details
    const attendanceRecords = await Attendance.find({ student: studentId })
      .populate("subject", "name code") // Populate subject name and code
      .exec();

    // Group attendance records by subject
    const attendanceBySubject = attendanceRecords.reduce((acc, record) => {
      const { subject, date, status } = record;

      // Initialize array for each subject if not present
      if (!acc[subject._id]) {
        acc[subject._id] = {
          subject: subject.name,
          code: subject.code,
          records: [],
        };
      }

      // Push date and status for each attendance record
      acc[subject._id].records.push({ date, status });
      return acc;
    }, {});

    // Respond with grouped attendance data
    res.status(200).json(Object.values(attendanceBySubject));
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
};
exports.addSubjectToStudent = async (req, res) => {
  try {
    const { rollNumber, subjectIds } = req.body;

    // Find the student by rollNumber
    const student = await Student.findOne({ rollNumber });
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    // Ensure only the `subjects` field is updated, not `attendance`
    student.subjects = [...new Set([...student.subjects, ...subjectIds])];

    // Save the updated student document
    await student.save();

    // Add the student to each subject's students array
    await Subject.updateMany(
      { _id: { $in: subjectIds } },
      { $push: { students: student._id } }
    );

    res.status(200).json({
      message: "Subjects added to student successfully",
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Something went wrong" });
  }
};
