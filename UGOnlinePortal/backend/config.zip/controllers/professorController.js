const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Professor = require("../models/Professor.js");
const Mark = require("../models/Mark.js");
const Student = require("../models/Student.js");
const Subject = require("../models/Subject.js");
const Attendance = require("../models/Attendance.js");
const mongoose = require("mongoose");
exports.registerProfessor = async (req, res) => {
  try {
    const { name, email, password, branches, sections } = req.body;

    const existingProfessor = await Professor.findOne({ email });
    if (existingProfessor) {
      return res.status(400).json({ message: "Professor already exists" });
    }

    const newProfessor = new Professor({
      name,
      email,
      password,
      branches,
      sections,
    });

    await newProfessor.save();

    res.status(201).json({ message: "Professor registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.loginProfessor = async (req, res) => {
  try {
    const { email, password } = req.body;

    const professor = await Professor.findOne({ email });
    if (!professor) {
      return res.status(404).json({ message: "Professor not found" });
    }

    const isPasswordCorrect = await professor.comparePassword(password);
    if (!isPasswordCorrect) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: professor._id, role: "professor" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.getProfessorProfile = async (req, res) => {
  try {
    const professor = await Professor.findById(req.userId).select("-password");
    if (!professor) {
      return res.status(404).json({ message: "Professor not found" });
    }

    res.status(200).json(professor);
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.updateProfessorProfile = async (req, res) => {
  try {
    const { name, email, branches, sections } = req.body;

    const updatedProfessor = await Professor.findByIdAndUpdate(
      req.userId,
      { name, email, branches, sections },
      { new: true }
    ).select("-password");

    res.status(200).json(updatedProfessor);
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};

exports.uploadMarks = async (req, res) => {
  try {
    const { studentId, subjectId, marks, type } = req.body;

    const student = await Student.findById(studentId);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }

    const newMark = new Mark({
      student: studentId,
      subject: subjectId,
      marks,
      type,
    });

    await newMark.save();

    res.status(201).json({ message: "Marks uploaded successfully" });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};
// exports.markAttendance = async (req, res) => {
//   try {
//     const { subjectId, section, branch, attendanceData } = req.body;
//     const professorId = req.userId;

//     const professor = await Professor.findById(professorId).populate(
//       "subjects"
//     );
//     const subject = professor.subjects.find(
//       (sub) => sub._id.toString() === subjectId
//     );

//     if (!subject) {
//       return res.status(403).json({
//         message: "You are not authorized to mark attendance for this subject",
//       });
//     }

//     if (!professor.sections.includes(section)) {
//       return res.status(403).json({
//         message: "You are not authorized to mark attendance for this section",
//       });
//     }

//     const attendanceRecords = attendanceData.map((student) => ({
//       student: student.studentId,
//       status: student.status,
//       subject: subjectId,
//       section,
//       branch,
//       date: new Date(),
//     }));

//     for (let record of attendanceRecords) {
//       const existingAttendance = await Attendance.findOne({
//         student: record.student,
//         subject: record.subject,
//         section: record.section,
//         date: record.date,
//       });

//       let attendanceDoc;
//       if (existingAttendance) {
//         existingAttendance.status = record.status;
//         attendanceDoc = await existingAttendance.save();
//       } else {
//         attendanceDoc = new Attendance(record);
//         await attendanceDoc.save();
//       }

//       // Update the student's attendance array
//       await Student.findByIdAndUpdate(
//         record.student,
//         { $addToSet: { attendance: attendanceDoc._id } }, // Avoid duplicates
//         { new: true }
//       );
//     }

//     res.status(200).json({ message: "Attendance marked successfully" });
//   } catch (error) {
//     res
//       .status(500)
//       .json({ message: "Failed to mark attendance", error: error.message });
//   }
// };
exports.markAttendance = async (req, res) => {
  try {
    const { subjectId, section, branch, attendanceData } = req.body;
    const professorId = req.userId;

    const professor = await Professor.findById(professorId).populate(
      "subjects"
    );
    const subject = professor.subjects.find(
      (sub) => sub._id.toString() === subjectId
    );

    if (!subject) {
      return res.status(403).json({
        message: "You are not authorized to mark attendance for this subject",
      });
    }

    if (!professor.sections.includes(section)) {
      return res.status(403).json({
        message: "You are not authorized to mark attendance for this section",
      });
    }

    const attendanceRecords = attendanceData.map((student) => ({
      student: student.studentId,
      status: student.status,
      subject: subjectId,
      section,
      branch,
      date: new Date(),
    }));

    for (let record of attendanceRecords) {
      const existingAttendance = await Attendance.findOne({
        student: record.student,
        subject: record.subject,
        section: record.section,
        date: record.date,
      });

      let attendanceDoc;
      if (existingAttendance) {
        existingAttendance.status = record.status;
        attendanceDoc = await existingAttendance.save();
      } else {
        attendanceDoc = new Attendance(record);
        await attendanceDoc.save();
      }

      // Update the student's attendance array
      await Student.findByIdAndUpdate(
        record.student,
        { $addToSet: { attendance: attendanceDoc._id } }, // Avoid duplicates
        { new: true }
      );
    }

    res.status(200).json({ message: "Attendance marked successfully" });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Failed to mark attendance", error: error.message });
  }
};
exports.getDashboard = async (req, res) => {
  try {
    const professorId = req.userId; // Assuming the professor's ID is in the JWT payload
    const subjects = await Subject.find({ professor: professorId });

    if (!subjects || subjects.length === 0) {
      return res.status(404).json({ message: "No subjects found." });
    }

    res.json(subjects);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch subjects." });
  }
};

exports.createSubject = async (req, res) => {
  try {
    const { name, code, branch } = req.body;
    const professorId = req.userId; // Assuming the professor's ID is in the JWT payload

    // Check if the professor exists
    const professor = await Professor.findById(professorId);
    if (!professor) {
      return res.status(404).json({ message: "Professor not found" });
    }

    // Create a new subject and link it to the professor
    const newSubject = new Subject({
      name,
      code,
      branch,
      professor: professorId,
    });

    await newSubject.save();

    // Update the professor document to include this new subject in their subjects array
    professor.subjects.push(newSubject._id);
    await professor.save();

    res.status(201).json({
      message: "Subject created and assigned successfully",
      subject: newSubject,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create and assign subject" });
  }
};

exports.getAttendance = async (req, res) => {
  try {
    const { subject, section } = req.query; // Get subject and section from query params

    // Log the incoming query parameters to ensure they are correct
    // console.log(`Subject: ${subject}`);
    // console.log(`Section: ${section}`);

    // Ensure the subject ID is properly converted to an ObjectId
    const subjectObjectId = new mongoose.Types.ObjectId(subject);

    // Log the subject ObjectId to verify correct conversion
    // console.log(`Subject ObjectId: ${subjectObjectId}`);

    // Query attendance based on the subject and section
    const students = await Attendance.find({
      subject: subjectObjectId, // Match subject by ObjectId
      section: section, // Match section exactly (case-sensitive)
    })
      .populate("student", "name rollNumber") // Populate student details (assuming you have a Student model)
      .exec();

    // Log the query result
    // console.log("Students:", students);

    if (students.length === 0) {
      // Return a message if no records are found
      return res.status(404).json({ message: "No attendance records found" });
    }

    // Format the attendance data to include student details and attendance percentage
    const attendanceData = students.map((student) => ({
      studentId: student.student._id,
      name: student.student.name,
      rollNumber: student.student.rollNumber,
      attendancePercentage: calculateAttendancePercentage(student),
    }));

    // Send the formatted attendance data as the response
    res.status(200).json(attendanceData);
  } catch (error) {
    // Log and return any errors that occur
    console.error("Error fetching attendance:", error);
    res.status(500).json({ message: "Error fetching attendance data" });
  }
};

// Utility function for calculating attendance percentage
function calculateAttendancePercentage(student) {
  // Ensure you have a `records` array in the student document that stores attendance status
  const totalClasses = student.attendance ? student.attendance.length : 0;
  const attendedClasses = student.records
    ? student.attendance.filter((attendance) => attendance.status === "Present")
        .length
    : 0;
  return totalClasses > 0 ? (attendedClasses / totalClasses) * 100 : 0;
}
